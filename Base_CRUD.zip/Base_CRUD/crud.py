from datetime import datetime 
from openpyxl import load_workbook


Rut="C:\\Users\\lenovo1\\OneDrive\\Escritorio\\Base_CRUD.xlsx"
Rut=r"C:\Users\lenovo1\OneDrive\Escritorio\Base_CRUD.xlsx"

def leer(ruta:str, extraer:str):
    Archivo_Exccel = load_workbook(ruta)
    Hoja_datos = Archivo_Exccel['Base del crud']
    Hoja_datos = Hoja_datos['A2':'F'+str(Hoja_datos.max_row)]

    info={}

    for i in Hoja_datos:

        if isinstance(i[0].value, int):
            info.setdefault(i[0].value,{'tarea':i[1].value, 'descripcion':i[2].value, 'estado':i[3].value, 
                                                'fecha de inicio':i[4].value, 'fecha de finalizacion':i[5].value})

    if not(extraer=='todo'):
            info=filtrar(info, extraer)

    for i in info:
            print('******** Tarea ********')
            print('Id'+ str(i)+'\n'+'Titulo:' +str(info[i]['Tarea'])+
                  '\n'+'Descripcion:'+str(info[i]['descripcion'])+ '\n'+'Estado:'
                  +str(info[i]['estado'])+'\n'+'Fecha Creacion:'+str(info[i]['fecha de inicio'])
                  +'\n'+'Fecha de finalizacion:'+str(info[i]['fecha de finalizacion']) )

            print()

    return

def filtrar(info:dict, filtro:str):
    aux={}

    for i in info:
        if info[i]['estado']==filtro:
            aux.setdefault(i,info[i])
    return aux

def actualizar(ruta:str, identificador:int, datos_actualizados:dict):
    Archivo_Exccel = load_workbook(ruta)
    Hoja_datos = Archivo_Exccel['Base del crud']
    Hoja_datos = Hoja_datos['A2','F'+str(Hoja_datos.max_row)]
    Hoja= Archivo_Exccel.active

    titulo=2 
    descripcion = 3
    estado = 4
    fecha_inicio = 5 
    fecha_finalizado =6
    encontro=False
    for i in Hoja_datos:
        if i[0].value==identificador:
            fila=i[0].row
            encontro=True 
            for d in datos_actualizados:
                if d=='titulo' and not (datosActualizados[d]==''):
                    Hoja.cell(row=fila, column=titulo).value=datosActualizados[d]
                elif d=='descripcion' and not (datosActualizados[d]==''):
                    Hoja.cell(row=fila, colmn=descripcion).value=datosActualizados[d]
                elif d=='estado' and not (datosActualizados[d]==''):
                    Hoja.cell(row=fila, column=estado).value=datosActualizados[d]
                elif d=='fecha inicio' and not (datosActualizados[d]==''):
                    Hoja.cell(row=fila, column=fecha_inicio).value=datosActualizados[d]
                elif d=='fecha finalizacion' and not (datosActualizados[d]==''):
                    Hoja.cell(row=fila, column=fecha_finalizado).value=datosActualizados[d]

    Archivo_Exccel.save(ruta)
    if encontro==False:
        print('Error: No existe una tarea con ese Id')
        print()
    return  


def agregar(ruta:int, datos:dict):
    Archivo_Exccel = load_workbook(ruta)
    Hoja_datos = Archivo_Exccel['Base del crud']
    Hoja_datos=Hoja_datos['A2','F'+str(Hoja_datos.max_row+1)]
    Hoja=Archivo_Exccel.active

    titulo=2 
    descripcion = 3
    estado = 4
    fecha_inicio = 5 
    fecha_finalizado =6
    for i in Hoja_datos:

        if not(isinstance(i[0].value, int)):
            identificador=i[0].row
            Hoja.cell(row=identificador, column=1).value=identificador-1
            Hoja.cell(row=identificador, column=titulo).value=datos['titulo']
            Hoja.cell(row=identificador, column=descripcion).value=datos['descripcion']
            Hoja.cell(row=identificador, column=estado).value=datos['estado']
            Hoja.cell(row=identificador, column=fecha_inicio).value=datos['fecha inicio']
            Hoja.cell(row=identificador, column=fecha_finalizado).value=datos['fecha finalizado']
            break
    Archivo_Exccel.save(ruta)
    return 

def borrar(ruta, identificador):
    Archivo_Execcel = load_workbook(ruta)
    Hoja_datos = Archivo_Execcel['Base del crud']
    Hoja_datos = Hoja_datos['A2':'F'+str(Hoja_datos.max_row)]
    Hoja=Archivo_Execcel.active

    titulo=2 
    descripcion = 3
    estado = 4
    fecha_inicio = 5 
    fecha_finalizado =6
    for i in Hoja_datos:
        if i[0].value==identificador:
            fila=i[0].row
            encontro=True 

            Hoja.cell(row=fila, colomn=1).value=""
            Hoja.cell(row=fila, colomn=titulo).value=""
            Hoja.cell(row=fila, colomn=descripcion).value=""
            Hoja.cell(row=fila, colomn=estado).value=""
            Hoja.cell(row=fila, colomn=fecha_inicio).value=""
            Hoja.cell(row=fila, colomn=fecha_finalizado).value=""

    Archivo_Execcel.save(ruta)
    if encontro==False:
        print('Error: No existe una tarea con esa Id')
        print()
    return       

Rut="C:\\Users\\lenovo1\\OneDrive\\Escritorio\\Base_CRUD"
datosActualizados={'titulo':'', 'descripcion':'', 'estado':'', 'fecha inicio':'', 'fecha finalizacion':''}
while True:
    print('Indique la accion que desea realizar:')
    print('Consultar: 1')
    print('Actualizar: 2 ')
    print('Crear nueva tarea: 3 ')
    print('Borrar: 4 ')
    accion = input('Escriba una opccion:')

    if not (accion=='1') and not (accion=='2')and not (accion=='3') and not (accion=='4'):
        print('Comando invalido por favor eliga una opccion validad')
    elif accion=='1':
        opc_consulta=''
        print('Indique la tarea que desea realizar:')
        print('Todas las tareas: 1')
        print('En espera: 2 ')
        print('En ejecucion: 3 ')
        print('Por aprobar: 4 ')
        print('Finalizado: 5 ')
        opc_consulta= input('Escriba la tarea que desee consultar:')
        if opc_consulta=='1':
           print()
           print()
           print('**Consultando todas las tareas en espera**')
           leer(Rut,'Todo')

        elif opc_consulta=='2': 
           print()
           print()
           print('**Consultando todas las tareas en espera**')
           leer(Rut,'En espera')